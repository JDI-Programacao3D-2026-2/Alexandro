using UnityEngine;
using UnityEngine.InputSystem;

// Movimento comum aos dois personagens jogadores.
// A velocidade é definida pelo SoldierPlayerController ou BerserkerPlayerController.
public class PlayerMove : MonoBehaviour
{
    [Header("Referências")]
    public Rigidbody rb;

    [Header("Movimento")]
    public float speed = 5f;

    [Header("Pulo")]
    public float jumpForce = 7f;

    private Transform cam;
    private Vector3 moveDirection;
    private float cameraYaw;
    private bool jumpRequested;

    // Conta quantos objetos com a tag Ground estão tocando o jogador.
    private int groundContacts;
    private bool IsGrounded => groundContacts > 0;

    void Awake()
    {
        if (rb == null)
            rb = GetComponent<Rigidbody>();

        if (rb == null)
        {
            Debug.LogError("PlayerMove precisa de um Rigidbody: " + name);
            enabled = false;
            return;
        }

        // Evita tombar para os lados. A rotação horizontal é controlada pela câmera.
        rb.constraints = RigidbodyConstraints.FreezeRotationX |
                         RigidbodyConstraints.FreezeRotationZ;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
    }

    void OnDisable()
    {
        // Limpa o estado ao morrer ou desativar o personagem.
        groundContacts = 0;
        moveDirection = Vector3.zero;
        jumpRequested = false;
    }

    // Lê o teclado e prepara a direção. A física fica no FixedUpdate.
    void Update()
    {
        if (cam == null && Camera.main != null)
            cam = Camera.main.transform;

        if (cam == null || Keyboard.current == null)
            return;

        cameraYaw = cam.eulerAngles.y;
        Quaternion yawRotation = Quaternion.Euler(0f, cameraYaw, 0f);

        Vector3 input = Vector3.zero;

        if (Keyboard.current[Key.W].isPressed) input.z += 1f;
        if (Keyboard.current[Key.S].isPressed) input.z -= 1f;
        if (Keyboard.current[Key.D].isPressed) input.x += 1f;
        if (Keyboard.current[Key.A].isPressed) input.x -= 1f;

        // O movimento acompanha a direção horizontal da câmera.
        moveDirection = yawRotation * Vector3.ClampMagnitude(input, 1f);

        // Espaço solicita o pulo somente quando está tocando o chão.
        if (Keyboard.current.spaceKey.wasPressedThisFrame && IsGrounded)
            jumpRequested = true;
    }

    void FixedUpdate()
    {
        if (rb == null)
            return;

        rb.MoveRotation(Quaternion.Euler(0f, cameraYaw, 0f));

        // Altera apenas X e Z, preservando a velocidade vertical da gravidade.
        Vector3 velocity = rb.linearVelocity;
        velocity.x = moveDirection.x * speed;
        velocity.z = moveDirection.z * speed;
        rb.linearVelocity = velocity;

        if (jumpRequested)
        {
            jumpRequested = false;

            if (IsGrounded)
            {
                // Zera a queda antes do impulso para o pulo ficar consistente.
                rb.linearVelocity = new Vector3(velocity.x, 0f, velocity.z);
                rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
            }
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
            groundContacts++;
    }

    void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
            groundContacts = Mathf.Max(0, groundContacts - 1);
    }
}
